# Walkthrough 2 Learning Journal

The camera would continue to draw pins when looking in the opposite direction. I found this article on the subject. http://www.turiyaware.com/a-solution-to-unitys-camera-worldtoscreenpoint-causing-ui-elements-to-display-when-object-is-behind-the-camera/
