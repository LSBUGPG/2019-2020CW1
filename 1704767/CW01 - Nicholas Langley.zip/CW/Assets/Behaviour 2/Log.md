# Walkthrough 2 Log

### 25/11/19

Began: 23:26

Finished : 00:15 09/12/19

Total: 0.49

### 26/11/19

Began: 20:30

Finished : 21:35

Total: 1.05
