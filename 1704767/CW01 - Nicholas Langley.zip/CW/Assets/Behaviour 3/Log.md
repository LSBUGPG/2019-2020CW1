# Walkthrough 3 Log

### 01/12/19

Began: 22:00

Finished: 22:57

Total: 0.57

### 02/12/19

Began: 14:11

Finished: 16:02

Total: 1:51
