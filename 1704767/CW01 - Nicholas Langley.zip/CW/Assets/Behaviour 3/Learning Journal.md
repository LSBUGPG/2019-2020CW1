# Walkthrough 3 Learning Journal

The Vector3 Lerp function takes a number Unity specifies should be between 0 and 1. Changing this value in the Editor without typing out the numbers be annoying when trying to fine tune the value. I found the RangeAttribute that you can include to give you a handy slider to let you accurately pick a value.  
