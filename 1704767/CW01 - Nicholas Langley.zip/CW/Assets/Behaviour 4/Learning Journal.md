# Walkthrough 4 Learning Journal

The TransformDirection function was very helpful in getting the PlayerLocomotion to work.
