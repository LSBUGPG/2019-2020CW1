# Walkthrough 4 Log

### 02/12/19

Began: 13:00

Finished: 13:51

Total: 0.51

### 03/12/19

Began: 19:35

Finished: 21:10

Total: 1.35
