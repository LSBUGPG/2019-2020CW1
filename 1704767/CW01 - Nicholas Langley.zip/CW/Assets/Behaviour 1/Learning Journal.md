# Walkthrough 1 Learning Journal

The Go-to maths struct Mathf for Unity doesn't have a particularly capable Rounding feature. I found a forum where someone mentioned the Systems Math struct and its Rounding functions and their capability to round to n decimal places (where n is >= 0 and <= 15).
