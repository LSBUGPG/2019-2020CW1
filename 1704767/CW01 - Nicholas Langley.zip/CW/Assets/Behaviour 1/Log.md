# Walkthrough 1 Log

### 23/11/19

Began: 18:55

Finished: 20:05

Total: 1.10

### 24/11/19

Began: 13:08

Finished: 14:20

Total: 1.12
