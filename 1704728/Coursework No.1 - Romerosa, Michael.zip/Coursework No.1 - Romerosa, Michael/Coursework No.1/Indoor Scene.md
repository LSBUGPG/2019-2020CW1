INDOOR SCENE


1. Making the indoor scene

        Make a new unity file in 3D.
        The newly create unity file will have the "Sample Scene".(You can change the name if you want)
        Windows > Rendering > Lighting Settings.
        Set the intensity to 0.1.
        On the Hierarchy, delete your "Directional light".
        

2. Done!

        Congratulations on making your indoor scene!
        You are awesome! 
