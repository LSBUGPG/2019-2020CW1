Programming Task Log
Date
Start
End
Interruptions
Time (H)
Task
29/10/2019
9:30
10:23
Looking for tutorials
0.53
Making roaming ai randomly work
29/10/2019
10:49
11:35
Looking for tutorials
0.46
Adding vision to my AI
29/10/2019
16:00
18:00
-
2
Figuring out how to use List for the random spawn of a game object without repeating
23/11/2019
22:00
3:38
break and playing a bit games
3.38
Building an beta for my game
09/12/2019
15:52
20:31
Breaks and Dinner
4.37
Writing the tutorials for coursework 1
