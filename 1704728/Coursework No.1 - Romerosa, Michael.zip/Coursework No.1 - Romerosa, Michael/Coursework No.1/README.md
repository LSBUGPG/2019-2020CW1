Player FP Controller and AI Random Roam

    A behaviour for first person controller and AI random roaming tutorial.
    Run the sample scene and check the AI random roam while controlling your the "Player" via a first person view.