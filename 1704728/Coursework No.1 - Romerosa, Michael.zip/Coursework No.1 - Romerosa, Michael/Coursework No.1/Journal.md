29/10/2019

    I was trying to change my patrol nav mesh agent AI to a random one. 
    After this one I watched some tutorials on how to add a vision sense for an AI. 
    It was quite easy as I only copy the code from the video I watch and add my own logic on how it will work if it sees a player.
    In the afternoon, I was figuring out how to add a behaviour that pick a key from a list then remove it from the list to avoid repeat pick.

23/11/19

    Building a beta for my game as I already finish all the basic game object from my game.
    It took me quite a while since I built it from scratch since my prototype are in a mess since I conduct my experiments in there, a really bad move.

09/12/2019

    I remembered that I have to make a tutorial for the Programming Coursework 1 so I did that.
    I used the behaviours I learned while making the prototype for my game for 3D game level design Coursework.

