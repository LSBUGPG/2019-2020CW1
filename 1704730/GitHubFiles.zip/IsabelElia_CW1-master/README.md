# IsabelElia_CW1

This is Isabel Elia's Submission for AME_5_GPG_1920 CW1. 

This submission includes:

* Programming Task Log
* Learning Journal
* 4 Tutorials
* Unity Project with component
