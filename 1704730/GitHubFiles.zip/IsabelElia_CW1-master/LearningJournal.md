# Learning Journal

## 15/10/19

Started to watch a tutorial on how to create a start menu, which can be found here: https://www.youtube.com/watch?v=zc8ac_qUXQY 
I will base my tutorial around what I learnt in this one.

Made notes whilst I was watching, and followed along. 

Struggled with the TextMeshPro stuff. Found it hard to scale and move the text. 
Turns out I had to ACTUALLY scale the text by selecting it from the hierarchy and scaling it, rather than just dragging the boundaries. 
This made snapping it to a button easier.

Deviated from the original tutorial, it's easier to create the button first then text.


## 22/10/19
Looked up a number of tutorials.

Struggled to find one I could get working and understand. Will spend more time researching tomorrow.

## 23/10/19
Found a tutorial I understood and followed, I will base my tutorial around what I learnt in this one. Wrote up some notes. 
https://www.youtube.com/watch?v=F5eE1YL1ZJY&list=PLl3CdNrMyGa8OllUg3RHFTITBjyd4oG9i&index=5 

## 29/10/19
Researched how to pick up objects. Was difficult discerning between pick ups and picking up and object. I was more looking for the holding of an item and moving it around like in a Bethesda game over picking up items for an inventory or a point system.

Eventually found what I wanted with this tutorial:https://www.youtube.com/watch?v=IEV64CLZra8&list=PLl3CdNrMyGa8OllUg3RHFTITBjyd4oG9i&index=6

I will base my tutorial around what I learnt in this one.

##  02/11/19

Had some problem when implimenting this into my game. Wouldn't seem to work when using a player object with a character controller on it whereas when I first tested it, I used a rigidbody. The object would move into the destination, which was parented to the player's hand, but would not move in relation to the hand but to the world. So the destination would be a seperate location even though it was parented to a set location.

Took a lot of playing around but I worked it out by comparing the original project I made to the current one. Realised it was that I had a rigidbody in the bug free version.

## 12/11/19
Researching a tutorial for a timer. Would like to implement a game over element too. These are the tutorials I'm planning to base mine on: https://www.youtube.com/watch?v=d7h49NKooKU & https://www.youtube.com/watch?v=o0j7PdU88a4


