# Programming Task Log

date     | start | end   | break | time taken  | description
---------|-------|-------|-------|-------------|-----------------------------------
15/10/19 | 18:25 | 18:44 |       |    00:19    | investigated menus
16/10/19 | 16:15 | 18:00 | 00.20 |    01:25    | followed and tested own tutorial
22/10/19 | 16:00 | 18:00 | 00:40 |    01:20    | investigated fps - movement
23/10/19 | 16:40 | 18:00 |       |    01:20    | investigated fps - movement
26/10/19 | 13:15 | 13:35 |       |    00:20    | investigated fps - mouse rot
29/10/19 | 16:00 | 18:00 | 00:40 |    01:20    | investigated pick up/hold objects
02/11/19 | 11:00 | 12:26 | 00:20 |    01:06    | pick up debug
05/11/19 | 16:10 | 18:00 | 00:30 |    01:20    | investigated timers
12/11/19 | 16:00 | 17:35 |       |    01:35    | investigated timers/win conditions
24/11/19 | 11:00 | 13:00 | 00:40 |    01:20    | timer debug
04/12/19 | 15:30 | 18:12 | 02:42 |    01:20    | timer debug and creating github repository and finalising submission



